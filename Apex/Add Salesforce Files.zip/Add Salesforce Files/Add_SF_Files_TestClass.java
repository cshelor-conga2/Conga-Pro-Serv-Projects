@isTest
global class addFilesExtensionTestClass {

	@testSetup
	public static testmethod void addFilesTest() {

		//Get Collab api settings
        Collaborate_API_Setting__mdt settings = addFilesExtension.APISettings;
        System.assert(settings != null);
        System.assert(String.isNotBlank(settings.api_key__c));
        System.assert(String.isNotBlank(settings.collaborate_api_endpoint__c));
       
        String api_key = settings.api_key__c;
        String endpoint = settings.collaborate_api_endpoint__c;
        String api_endpoint = endpoint + '/medias?api_key=' + api_key;


		Test.setMock(HttpCalloutMock.class, new CollaborateCreateFileHTTPMock());
       
        Test.startTest();
       
        tinderbox__Document__c testDoc = new tinderbox__Document__c();
        testDoc.Name = 'Test Collaborate Document';
        testDoc.tinderbox__Template_Name__c = '401(K) Welcome Kit';
        testDoc.tinderbox__TinderBoxId__c = '123456';
        insert testDoc;
       
        Test.stopTest();
       

	}

	public static testmethod void addFilesErrorTest(){
        //Get Collab api settings
        Collaborate_API_Setting__mdt settings = addFilesExtension.APISettings;
        System.assert(settings != null);
        System.assert(String.isNotBlank(settings.API_Key__c));
        System.assert(String.isNotBlank(settings.collaborate_api_endpoint__c));
       
        String api_key = settings.api_key__c;
        String endpoint = settings.collaborate_api_endpoint__c;
        String api_endpoint = endpoint + '/medias?api_key=' + api_key;
       
        Test.setMock(HttpCalloutMock.class, new CollaborateCreateFileErrorHTTPMock());
       
        Test.startTest();
       
        tinderbox__Document__c testDoc = new tinderbox__Document__c();
        testDoc.Name = 'Test Collaborate Document';
        testDoc.tinderbox__Template_Name__c = 'Test Collaborate Template';
        testDoc.tinderbox__TinderBoxId__c = '123456';
        insert testDoc;
       
        Test.stopTest();
       
    }
 
    global class CollaborateCreateFileHTTPMock implements HttpCalloutMock {
        global HTTPResponse respond(HTTPRequest req){
            HttpResponse res = new HttpResponse();
            res.setHeader('Content-Type', 'Application/JSON');
 
            ////// BUILD RESPONSE BODY FOR HTTP 'POST' //////
            String body = '{"media":{';
                  body += '"id":790211,';
                  body += '"name":"API Test",';
                  body += '"document_file_name":"API_Test",';
                  body += '"document_content_type":"application/pdf",';
                  body += '"document_file_size":50648';
               body += '}';
            body += '}';
       
            res.setBody(body);
            res.setStatusCode(201);
            return res;
        }
    }
   
    public class CollaborateCreateFileErrorHTTPMock implements HttpCalloutMock {
        public HTTPResponse respond(HTTPRequest req){
            HttpResponse res = new HttpResponse();
            res.setHeader('Content-Type', 'Application/JSON');
           
            String body = '{"test": {"document": "new document"}}';
           
            res.setBody(body);
            res.setStatusCode(404);
            return res;
        }
    }	
}